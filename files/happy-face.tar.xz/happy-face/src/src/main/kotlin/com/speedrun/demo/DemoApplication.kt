package com.speedrun.demo

import freemarker.template.Configuration
import freemarker.template.Template
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.RestController
import java.io.StringReader
import java.io.StringWriter



@SpringBootApplication
@RestController
class DemoApplication {
	@GetMapping("/")
	@ResponseBody
	fun index(@RequestParam(required = false, defaultValue = "I'm \uD83D\uDE22 and \uD83D\uDE1E but was \uD83D\uDE3F and \uD83D\uDE2D before.") text: String): String {

		val badChars = arrayOf("<", ">", "\\")

		badChars.forEach { c ->
			if (text.contains(c)){
				return "Please no XSS"
			}
		}

		val sadToHappy = mapOf(
			"😢" to "😊",
			"😞" to "😁",
			"😔" to "😄",
			"☹️" to "🙂",
			"🙁" to "😃",
			"😩" to "😆",
			"😫" to "😅",
			"😿" to "😸",
			"😭" to "😂",
			"😣" to "😌",
			"😖" to "😋",
			"😟" to "😉",
			"😬" to "😎",
			"😓" to "😇",
			"😥" to "😍",
			"(" to ")"
		)

		val output = sadToHappy.entries.fold(text) { acc, (sad, happy) ->
			acc.replace(sad, happy)
		}


		val templateString = """
<!DOCTYPE html>
	<head>
		<style>
		body {
		  font-family: Arial, sans-serif;
		  background: #f0f8ff;
		  color: #333;
		  padding: 2rem;
		  max-width: 600px;
		  margin: auto;
		}

		h1 {
		  color: #ff6f61;
		  text-align: center;
		  font-size: 2.5rem;
		  margin-bottom: 1rem;
		}

		p {
		  font-size: 1.2rem;
		  text-align: center;
		  margin-bottom: 2rem;
		}

		form {
		  display: flex;
		  flex-direction: column;
		  gap: 1rem;
		}

		textarea {
		  width: 100%;
		  height: 150px;
		  padding: 1rem;
		  border: 2px solid #ccc;
		  border-radius: 0.5rem;
		  resize: vertical;
		  font-size: 1rem;
		}

		button {
		  align-self: flex-end;
		  padding: 0.6rem 1.2rem;
		  background-color: #4caf50;
		  color: white;
		  border: none;
		  border-radius: 0.5rem;
		  font-size: 1rem;
		  cursor: pointer;
		  transition: background 0.3s;
		}

		button:hover {
		  background-color: #45a049;
		}

		pre {
		  background: #fffbe6;
		  padding: 1rem;
		  border: 1px solid #ffe58f;
		  border-radius: 0.5rem;
		  margin-bottom: 2rem;
		  white-space: pre-wrap;
		  word-wrap: break-word;
		}
		</style>	
	</head>
	<body>
		<h1>Happy Faces</h1>
		<p>
  			Turn any text into a cheerful version with our advanced AI.
		</p>
		<pre>$output</pre>
		<form>
			<textarea name="text">$text</textarea>
			<button type="submit">Convert</button>
		</form>
	</body>
	
				""".trimIndent()

		val template = Template("index", StringReader(templateString), Configuration.getDefaultConfiguration())

		val writer = StringWriter()
		template.process(null, writer)
		return writer.toString()
	}

	companion object {
		@JvmStatic
		fun main(args: Array<String>) {
			SpringApplication.run(DemoApplication::class.java, *args)
		}
	}
}
